int round_forward_wrapper(THCudaTensor *bottom_tensor, THCudaTensor *top_tensor, int count);
int round_backward_wrapper(THCudaTensor *bottom_tensor, THCudaTensor *top_tensor, int count);
