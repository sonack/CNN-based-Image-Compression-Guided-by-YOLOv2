#!/bin/bash

make clean
make all
python build_ffi.py